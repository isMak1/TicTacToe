package com.ttt

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    var scoreX: Int = 0
    var scoreO: Int = 0
    var tour: Int = 1
    var won: Boolean = false
    var player: String = "JoueurX"
    var result: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            if (ajouterJoueur.text.toString() == "") {
                Toast.makeText(
                    this@MainActivity,
                    "Il faut inscrire un nom valide",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                joueur1.text =
                    ajouterJoueur.text.toString().plus(" point: ".plus(scoreX.toString()))
                button.text = "Joueur 2"
                ajouterJoueur.setText("")
                button.setOnClickListener {
                    if (ajouterJoueur.text.toString() == "") {
                        Toast.makeText(
                            this@MainActivity,
                            "Il faut inscrire un nom valide",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        joueur2.text =
                            ajouterJoueur.text.toString().plus(" point: ".plus(scoreO.toString()))
                        button.text = "RECOMMENCER"
                        ajouterJoueur.setText("")
                        button.setOnClickListener {
                            resetGrid()
                            tour = 1
                            player = result
                        }
                    }
                }
            }
        }
    }

    fun play(imageView: View) {
        if (button.text.toString() == "RECOMMENCER") {
            when (player) {
                "JoueurX" -> {
                    imageView.setBackgroundResource(R.drawable.x)
                    imageView.isEnabled = false
                }

                "JoueurO" -> {
                    imageView.setBackgroundResource(R.drawable.o)
                    imageView.isEnabled = false
                }
            }
            winner()
            swapPlayer()
            tour++
        }
    }

    fun swapPlayer() {
        if (player == "JoueurX")
            player = "JoueurO"
        else player = "JoueurX"
    }

    fun resetGrid() {
        imageView1.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView1.isEnabled = true
        imageView2.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView2.isEnabled = true
        imageView3.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView3.isEnabled = true
        imageView4.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView4.isEnabled = true
        imageView5.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView5.isEnabled = true
        imageView6.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView6.isEnabled = true
        imageView7.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView7.isEnabled = true
        imageView8.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView8.isEnabled = true
        imageView9.setBackgroundResource(android.R.drawable.divider_horizontal_dark)
        imageView9.isEnabled = true
    }

    fun disableGrid() {
        imageView1.isEnabled = false
        imageView2.isEnabled = false
        imageView3.isEnabled = false
        imageView4.isEnabled = false
        imageView5.isEnabled = false
        imageView6.isEnabled = false
        imageView7.isEnabled = false
        imageView8.isEnabled = false
        imageView9.isEnabled = false
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    fun winner() {
        try {
            when {
                Objects.equals(
                    imageView1.getBackground().getConstantState(),
                    resources.getDrawable(R.drawable.x).getConstantState()
                ) &&
                        Objects.equals(
                            imageView2.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView4.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView6.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView8.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView1.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView4.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView2.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView8.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView6.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView1.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.x).getConstantState()
                        )

                -> {
                    val name: String = joueur1.text.toString().substringBefore(" ")
                    joueur1.text =
                        joueur1.text.toString()
                            .replace(scoreX.toString(), (scoreX + 1).toString())
                    Toast.makeText(
                        this@MainActivity,
                        "$name est gagnant",
                        Toast.LENGTH_SHORT
                    ).show()
                    disableGrid()
                    result = "JoueurX"
                    scoreX += 1
                    won = true
                }
                Objects.equals(
                    imageView1.getBackground().getConstantState(),
                    resources.getDrawable(R.drawable.o).getConstantState()
                ) &&
                        Objects.equals(
                            imageView2.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView4.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView6.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView8.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView1.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView4.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView2.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView8.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView6.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView1.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView9.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) ||

                        Objects.equals(
                            imageView3.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView5.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        ) &&
                        Objects.equals(
                            imageView7.getBackground().getConstantState(),
                            resources.getDrawable(R.drawable.o).getConstantState()
                        )
                -> {
                    val name: String = joueur2.text.toString().substringBefore(" ")
                    joueur2.text =
                        joueur2.text.toString()
                            .replace(scoreO.toString(), (scoreO + 1).toString())
                    Toast.makeText(
                        this@MainActivity,
                        "$name est gagnant",
                        Toast.LENGTH_SHORT
                    ).show()
                    disableGrid()
                    result = "JoueurO"
                    scoreO += 1
                    won = true
                }
                tour > 8 -> {
                    Toast.makeText(
                        this@MainActivity,
                        "La partie est null",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } catch (exception: Exception) {
            return
        }
    }
}

